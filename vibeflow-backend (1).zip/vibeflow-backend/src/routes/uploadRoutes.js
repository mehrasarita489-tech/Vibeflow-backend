const express = require('express');
const router = express.Router();

router.post('/video', async (req, res) => {
  try {
    const fakeUrl = 'https://your-cdn.com/videos/' + Date.now() + '.mp4';
    return res.json({ url: fakeUrl });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Upload failed' });
  }
});

module.exports = router;
