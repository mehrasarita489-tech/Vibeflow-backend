const express = require('express');
const auth = require('../middleware/authMiddleware');
const Video = require('../models/Video');
const Comment = require('../models/Comment');

const router = express.Router();

router.post('/', auth, async (req, res) => {
  try {
    const { videoId, text } = req.body;
    if (!text) return res.status(400).json({ message: 'Empty comment' });

    const newComment = await Comment.create({
      video: videoId,
      user: req.user._id,
      text,
    });

    await Video.findByIdAndUpdate(videoId, { $inc: { commentCount: 1 } });

    return res.status(201).json(newComment);
  } catch (e) {
    console.error(e);
    return res.status(500).json({ message: 'Add comment failed' });
  }
});

router.get('/:videoId', async (req, res) => {
  try {
    const { videoId } = req.params;

    const comments = await Comment.find({ video: videoId })
      .populate('user', 'username avatarUrl')
      .sort({ createdAt: -1 });

    return res.json(comments);
  } catch (e) {
    console.error(e);
    return res.status(500).json({ message: 'Fetch comments failed' });
  }
});

module.exports = router;
