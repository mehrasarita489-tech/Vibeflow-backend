const express = require('express');
const Video = require('../models/Video');

const router = express.Router();

router.post('/caption', async (req, res) => {
  try {
    const { videoUrl } = req.body;
    if (!videoUrl) {
      return res.status(400).json({ message: 'videoUrl required' });
    }

    const caption = 'AI: Epic moment captured! 🔥 #vibeflow #ai';
    return res.json({ caption });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'AI caption failed' });
  }
});

router.get('/feed', async (req, res) => {
  try {
    const userId = req.query.userId;
    const limit = Number(req.query.limit) || 20;

    let videos = await Video.find({})
      .populate('user', 'username displayName avatarUrl')
      .lean();

    const now = Date.now();

    videos = videos.map((v) => {
      const ageHours = Math.max(
        1,
        (now - new Date(v.createdAt).getTime()) / (1000 * 60 * 60)
      );

      const engagementScore =
        (v.likeCount || 0) * 2 +
        (v.commentCount || 0) * 3 +
        (v.shareCount || 0) * 4;

      const timeDecay = 1 / Math.sqrt(ageHours);
      const randomBoost = Math.random() * 5;

      const finalScore = engagementScore * timeDecay + randomBoost;

      return { ...v, _score: finalScore };
    });

    videos.sort((a, b) => b._score - a._score);

    videos = videos.slice(0, limit);

    return res.json(videos);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'AI feed failed' });
  }
});

module.exports = router;
