const express = require('express');
const Video = require('../models/Video');
const User = require('../models/User');
const auth = require('../middleware/authMiddleware');

const router = express.Router();

router.post('/', auth, async (req, res) => {
  try {
    const { videoUrl, caption } = req.body;

    if (!videoUrl) {
      return res.status(400).json({ message: 'videoUrl required' });
    }

    const userId = req.user._id;

    const hashtags =
      caption?.match(/#\w+/g)?.map((tag) => tag.toLowerCase()) || [];

    const video = await Video.create({
      user: userId,
      videoUrl,
      caption,
      hashtags,
      music: 'Unknown',
    });

    return res.status(201).json(video);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Create post failed' });
  }
});

router.get('/feed', async (req, res) => {
  try {
    const limit = Number(req.query.limit) || 20;

    const videos = await Video.find({})
      .sort({ createdAt: -1 })
      .limit(limit)
      .populate('user', 'username displayName avatarUrl');

    return res.json(videos);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Failed to get feed' });
  }
});

router.get('/user/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    const videos = await Video.find({ user: userId })
      .sort({ createdAt: -1 })
      .lean();

    return res.json(videos);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Failed to get user videos' });
  }
});

module.exports = router;
