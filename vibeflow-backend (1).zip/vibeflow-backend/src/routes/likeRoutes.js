const express = require('express');
const auth = require('../middleware/authMiddleware');
const Video = require('../models/Video');
const Like = require('../models/Like');

const router = express.Router();

router.post('/like', auth, async (req, res) => {
  try {
    const { videoId } = req.body;
    const userId = req.user._id;

    const existing = await Like.findOne({ video: videoId, user: userId });
    if (existing) {
      return res.status(400).json({ message: 'Already liked' });
    }

    await Like.create({ video: videoId, user: userId });
    await Video.findByIdAndUpdate(videoId, { $inc: { likeCount: 1 } });

    return res.json({ message: 'Liked' });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ message: 'Like failed' });
  }
});

router.post('/unlike', auth, async (req, res) => {
  try {
    const { videoId } = req.body;
    const userId = req.user._id;

    const existing = await Like.findOne({ video: videoId, user: userId });
    if (!existing) {
      return res.status(400).json({ message: 'Not liked' });
    }

    await Like.deleteOne({ _id: existing._id });
    await Video.findByIdAndUpdate(videoId, { $inc: { likeCount: -1 } });

    return res.json({ message: 'Unliked' });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ message: 'Unlike failed' });
  }
});

router.get('/status', auth, async (req, res) => {
  try {
    const { videoId } = req.query;
    const userId = req.user._id;

    const existing = await Like.findOne({ video: videoId, user: userId });

    return res.json({ liked: !!existing });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ message: 'Status failed' });
  }
});

module.exports = router;
