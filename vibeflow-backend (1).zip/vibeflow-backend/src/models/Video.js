const mongoose = require('mongoose');

const videoSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    videoUrl: { type: String, required: true },
    caption: { type: String },
    music: { type: String },
    hashtags: [{ type: String }],
    likeCount: { type: Number, default: 0 },
    commentCount: { type: Number, default: 0 },
    shareCount: { type: Number, default: 0 },
    aiMeta: {
      language: String,
      mood: String,
      autoCaption: String,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Video', videoSchema);
